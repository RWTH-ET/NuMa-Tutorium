# PP2 – Task 3: Fehleranalyse der Polynominterpolation

Eigenständige Lösung der Aufgaben **3a, 3b und 3c** des Programmierprojekts 2 (Thermoelement-Kennlinie). Dieser Ordner kann als Ganzes in ein GitHub-Repository übernommen werden. Andere Tasks oder Dateien aus dem Gesamtprojekt werden nicht benötigt.

## Start

Python 3.10 oder neuer verwenden. Im Ordner dieses Projekts ausführen:

`sh
python -m pip install -r requirements.txt
python main.py
`

Unter macOS/Linux heißt der Python-Aufruf gegebenenfalls python3.
Alle Dateipfade werden relativ zum Skript aufgelöst. Das Programm benötigt keine Internetverbindung und überschreibt beim erneuten Ausführen ausschließlich seine Ergebnisdateien.

## Dateien

- main.py: Experimente 3a, 3b und 3c sowie Export der Messwerte.
- interpolation.py: baryzentrische Interpolation, Vandermonde/Horner und SVG-Diagramme.
- data/: unveränderte drei CSV-Dateien aus den bereitgestellten Projektmaterialien. Die Kommentarzeile wird beim Einlesen ignoriert; die Werte sind durch Leerzeichen getrennt.
- rgebnisse/: fünf logarithmische Diagramme, zwei Messwerttabellen und die automatisch erzeugte Messauswertung. In der äquidistanten Tabelle steht bei den nicht geforderten Größen aus 3c 
an.

Die Materialien stammen aus der Lehrveranstaltung Numerische Mathematik für Elektrotechnik, Wintersemester 2026/27. Die Aufgabenstellung nennt NIST ITS-90 als Referenz der Kennlinie. Es wurden keine neuen Referenzdaten erzeugt.

## Diagramme

### 3a – Interpolationsfehler

![Interpolationsfehler](ergebnisse/3a_interpolationsfehler.svg)

### 3b – Datenfehler und Schranke

![Äquidistante Stützstellen](ergebnisse/3b_aequidistant.svg)

![Tschebyscheff-Stützstellen](ergebnisse/3b_tschebyscheff.svg)

### 3c – Koeffizientenänderung und Verfahrensfehler

![Relative Änderungen](ergebnisse/3c_relative_aenderung.svg)

![Koeffizientenfehler und Kondition](ergebnisse/3c_koeffizientenfehler.svg)

Die violette Kurve im letzten Diagramm gehört zur rechten Achse. Alle Fehlermaxima beziehen sich auf die 2000 Punkte des bereitgestellten Prüfrasters. Die Lebesgue-Konstante wird ebenfalls auf diesem Raster angenähert. Die Spannungen bleiben wie vorgegeben unskaliert in mV; gerechnet wird mit float64. Alle Fehlerachsen sind logarithmisch.

## Antworten auf die Teilfragen

## 3a – Interpolationsfehler

Mit den exakten Stützwerten wird baryzentrisch p[T_exakt] berechnet und mit der exakten Temperatur auf dem Prüfraster verglichen. Tschebyscheff-Stützstellen liefern eine rasche Abnahme: von ungefähr 2,17861 °C bei n=2 auf 4,90·10^-9 °C bei n=40. Äquidistant nimmt der Fehler in diesem Experiment insgesamt wesentlich langsamer ab: von 2,2289 °C auf ungefähr 0,0254 °C. Bei sehr hohen äquidistanten Graden können auch die baryzentrischen Referenzwerte durch Auslöschung beeinflusst werden; die Zahlen sind keine hochpräzise Referenzrechnung.

Das Lemma von Lebesgue liefert e_interp ≤ (1+Λ_n) · min_{q∈Π_n} ||T_exakt−q||∞. Der erste Faktor hängt von der Stützstellenlage und dem Grad ab, der zweite von der Kennlinie, dem Intervall und dem verfügbaren Polynomgrad. Die beste Approximation verbessert sich mit größerem Polynomraum, doch eine stark wachsende Lebesgue-Konstante kann diesen Vorteil aufheben. Die Abschätzung erklärt das Risiko äquidistanter Stützstellen; sie erzwingt keine konkrete Fehlerkurve und benötigt zur numerischen Vorhersage zusätzlich eine Schranke für den Bestapproximationsfehler.

## 3b – Datenfehler

Berechnet werden max|p[T_kalibrator]−p[T_exakt]| und die Lebesgue-Funktion ∑|ℓ_j(E)|. Ihr Maximum über das Prüfraster wird mit 0,005 °C multipliziert. Das liefert auf genau diesem Raster eine gültige Schranke. Dieses diskrete Maximum ist eine untere Näherung an die kontinuierliche Lebesgue-Konstante und wird nicht als zertifiziertes Maximum über das ganze Intervall ausgegeben.

Bei kleinen Graden dominiert der Interpolationsfehler. Bei großen Graden dominiert die Rundung der Stützwerte. Äquidistant liegt der Datenfehler bei n=20 bereits bei etwa 11,0979 °C und bei n=40 bei 2,67642·10^6 °C. Das erklärt den enormen Gesamtfehler aus 1b. Bei Tschebyscheff bleibt er im Bereich weniger Tausendstel Grad, beispielsweise etwa 0,00558 °C bei n=20. Mehr Stützstellen überwinden daher die Kalibratorauflösung nicht zuverlässig. Der Gesamtfehler muss wegen möglicher gegenseitiger Aufhebung nicht größer als jeder einzelne Fehleranteil sein.

Die Schranke ist ein Worst-Case-Ergebnis, keine Gleichheit und keine positive untere Fehlerschranke. Mit den vorliegenden gerundeten Daten lässt sich durch bloßes Erhöhen des Grades keine beliebig genaue Umrechnung garantieren. Dafür wären genauere Stützwerte beziehungsweise zusätzliche Annahmen über die Daten nötig.

## 3c – Koeffizientenfehler

Nur für Tschebyscheff-Stützstellen werden die Monomkoeffizienten zu exakten und gerundeten Daten verglichen. Ihre relative Änderung kann wesentlich größer als die relative Datenänderung sein. Bei n=20 beträgt sie ungefähr 0,0289, bei n=40 ungefähr 1,224. Trotzdem ist der baryzentrische Datenfehler der Polynomwerte nur ungefähr 0,00558 beziehungsweise 0,00652 °C. Große Änderungen der Monomkoeffizienten können sich in den Funktionswerten gegenseitig aufheben. Für hohe n enthalten die berechneten Koeffizientenänderungen zusätzlich Lösungsfehler; sie sind keine exakte Messung der reinen Datensensitivität.

Als e_koeff wird gemäß Aufgabenstellung max|p_Vandermonde−p_baryzentrisch| verwendet. Darin stecken sowohl Fehler der Koeffizientenberechnung als auch der Horner-Auswertung und ein kleiner Referenzfehler der baryzentrischen Auswertung. e_koeff liegt bei n=20 bei etwa 9,83·10^-5 °C, bei n=30 bei 0,0527 °C und bei n=40 bei 0,3955 °C. Die zunehmende Matrixkondition macht diese Abweichungen plausibel, sagt aber ihren genauen Betrag oder monotonen Verlauf nicht voraus. Das erklärt, warum Vandermonde in Aufgabe 2 für hohe Grade unzuverlässig wird.

## Empfehlung für die Lötstation

Tschebyscheff-Stützstellen und baryzentrische Auswertung. Für das vorgegebene Ziel genügt bereits n=9 auf dem Prüfraster. Als Wahl mit mehr Abstand zur Fehlerschwelle eignet sich n=15: Der gemessene Gesamtfehler beträgt etwa 0,004671 °C und ist das Minimum der untersuchten baryzentrischen Ergebnisse. Größere Grade bringen wegen der gerundeten Kalibratorwerte keinen verlässlichen Vorteil. Die Aussage gilt für das bereitgestellte Prüfraster und ersetzt keinen Nachweis des Fehlers zwischen dessen Punkten.


## Numerische Prüfungen

Beim Ausführen werden die Anzahl der Stützstellen, die Rundungsgrenze, die Datenfehlerschranke und für 3c die punktweise additive Fehlerzerlegung geprüft. Beide Interpolationsverfahren wurden zusätzlich mit einem bekannten quadratischen Polynom kontrolliert. Die mitgelieferten Ergebnisdateien wurden mit NumPy 2.3.5 erzeugt. Insbesondere Vandermonde-Ergebnisse bei hohen Graden können je nach NumPy-Version und Rechenbibliothek abweichen.

[Messauswertung mit Zahlen](ergebnisse/messauswertung.md)
